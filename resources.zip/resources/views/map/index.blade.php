@extends('main')

@section('content')
<style type="text/css">
    #map{
        height: 100%;
    }
</style>
    <div class="container-fluid ">
        <div class="row">
            <div class="col-md-4">

                        <div class="card card-grey-rounded px-4 pt-4 mb-5 mx-5">
            <form action="{{route('get.map.search.show') }}" method="get" id="search-form" >
                <div class="row">
                
                    <div class="col-md-12">
                        <div class="form-group row">
                            <label class="col-sm-12 col-form-label">@lang('admin.name')</label>
                            <div class="col-sm-12">
                               <input class="form-control" name="name" value="{{ app('request')->input('name') }}" type="search"  >
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row">
                            <label class="col-sm-12 col-form-label">@lang('admin.region')</label>
                            <div class="col-sm-12">
                                <select class="input-select2 custom-select" id="region_ids" multiple="multiple" >
                                    <option value="">@lang('admin.notExist')</option>
                                    @foreach($regions as $region)
                                      
                                            <option value="{{$region->id}}"> {{$region->name .' - '. $region->city->name}} </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                                            <div class="form-group row">
                            <label class="col-sm-12 col-form-label">@lang('admin.numberOfRooms')</label>
                            <div class="col-sm-12">
                                <select class="custom-select" name="number_of_rooms_id"  >
                                    <option value="">@lang('admin.notExist')</option>
                                    @foreach($number_of_rooms as $number_of_room)
                                        <option value="{{$number_of_room->id}}" @if( app('request')->input('number_of_rooms_id') == $number_of_room->id) selected @endif> {{$number_of_room->name}} </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>



                     <div class="col-md-12">
                        <div class="form-group row">
                            <label class="col-sm-12 col-form-label">@lang('admin.category')</label>
                            <div class="col-sm-12">
                                <select class="input-select2 custom-select" name="category_id_fk">
                                    <option value="">@lang('admin.notExist')</option>
                                    @foreach($category as $data)
                                    <option value="{{$data->id}}"> {{$data->name}} </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>

                     <div class="col-md-12">
                        <div class="form-group row">
                            <label class="col-sm-12 col-form-label">@lang('admin.instalment')</label>
                            <div class="col-sm-12">
                                <select class="input-select2 custom-select" name="instalment_id_fk">
                                    <option value="">@lang('admin.notExist')</option>
                                    @foreach($instalment as $data)
                                    <option value="{{$data->id}}"> {{$data->name}} </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                     <div class="col-md-12">
                        <div class="form-group row">
                            <label class="col-sm-12 col-form-label">@lang('admin.projectType')</label>
                            <div class="col-sm-12">
                                <select class="input-select2 custom-select" name="project_type">
                                    <option value="">@lang('admin.notExist')</option>
                                    <option value="resident" @if( app('request')->input('project_type') == 'invest_resident') selected @endif > @lang('admin.invest_resident') </option>
                                    <option value="resident" @if( app('request')->input('project_type') == 'resident') selected @endif > @lang('admin.resident') </option>
                                    <option value="hotel" @if( app('request')->input('project_type') == 'hotel') selected @endif> @lang('admin.hotel') </option>
                                    <option value="invest" @if( app('request')->input('project_type') == 'invest') selected @endif> @lang('admin.invest') </option>
                                </select>
                            </div>
                        </div>
                    </div>
                 <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-sm-12 col-form-label"></label>
                            <div class="col-sm-12 text-center">
                                <button class="btn btn-primary fontLight submit-btn mt-4"  type="submit">
                                        @lang('admin.search')
                                </button>  
                            </div>
                        </div>
                    </div>
                    


                </div>
        
        </form>
        </div>

            </div>
            <div class="col-md-8">
            <div id="map"></div>
        </div>

        </div>
    </div>
@endsection
@section('script')
<script src="https://unpkg.com/@googlemaps/markerclusterer/dist/index.min.js"></script>

<script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjF8tXV35Zu_dkzWcV0EDWmUBeClDgzbM&callback=initMap"></script>
<script>

var locations =[
 @foreach ($maps_data as $item)
    @if(empty($item->project_id))
        [{{ $item->id}}, {{ $item->lat }} , {{ $item->lng }} , "{{ $item->Project->name }}"],
    @else
         [{{ $item->id}}, {{ $item->lat }} , {{ $item->lng }} , "{{ $item->Project->name }}"],
    @endif
 @endforeach

]



  function initMap() {

    var myOptions = {
      center: new google.maps.LatLng(33.890542, 151.274856),
      zoom: 8,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    var map = new google.maps.Map(document.getElementById("map"),
        myOptions);
    setMarkers(map,locations)

  }



  function setMarkers(map,locations){

      var marker, i

for (i = 0; i < locations.length; i++)
 {  

 var loan = locations[i][0]
 var lat = locations[i][1]
 var long = locations[i][2]
 var title =  locations[i][3]

 latlngset = new google.maps.LatLng(lat, long);

  var marker = new google.maps.Marker({  
          map: map, title: loan , position: latlngset  
        });
        map.setCenter(marker.getPosition())


        var content = '<h5> مشروع : '  + title +  '</h5>' ;     

  var infowindow = new google.maps.InfoWindow()

google.maps.event.addListener(marker,'click', (function(marker,content,infowindow){ 
        return function() {
           infowindow.setContent(content);
           infowindow.open(map,marker);
        };
    })(marker,content,infowindow)); 

  }
  }

    </script>
@endsection