@include('inc.header')
@include('inc.menu')


@yield('content')


@include('inc.footer')